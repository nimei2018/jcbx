#!/usr/bin/env python
# *-* coding:utf-8 *-*


import re
import os
import sys
import time
import datetime
import subprocess
from time import clock as now
import smtplib
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart


time1 = now()


#CP = sys.argv[1]


## 取前一天时间方法二
before = datetime.datetime.now() - datetime.timedelta(days=1)
beforedate = before.strftime("%Y-%m-%d")
#LOG_DIR = '/data/' + CP + '/' + ROLE + '/access_log'
backupdir = '/opt/domaincount/' + beforedate

## global var
lfile = backupdir + '/' + 'nimei2.txt'


## 获取文件函数
def getfile():
     subprocess.Popen("mkdir -p " + backupdir, shell=True)

     #print "cd " + LOG_DIR + ' && ' + 'ls -lthr --time-style=long-iso | awk ' + "'" + '/' + beforedate + '/' + "'" + " | awk '{print $NF}'"
     flist = "cd " + LOG_DIR + ' && ' + 'ls -lthr --time-style=long-iso | awk ' + "'" + '/' + beforedate + '/' + "'" + " | awk '{print $NF}'"
     f2 = subprocess.Popen(flist, stdout=subprocess.PIPE, shell=True)
     f2.wait()
     file1 = f2.stdout.read().replace('\n', ' ')


     if len(file1):
     #if os.path.exists(LOG_DIR + '/' + file1):
         #print "cd " + LOG_DIR + ' && ' + "cat  " + file1 + '> ' + lfile
         file2 = "cd " + LOG_DIR + ' && ' + "cat  " + file1 + '> ' + lfile
         f1 = subprocess.Popen(file2, shell=True)
         f1.wait()
     else:
         #print LOG_DIR + ' file is not exists'
         return 0


## 处理文件函数
def treatfile(log_path = lfile):
    ## 定义一个空字典用于存储split的值
    ip_info = {}


    ## 存储对dict ip_info again modify的result
    new_ip_info = {}

    #print log_path
    #if os.stat(log_path).st_size == 0:
    #    sys.exit()
    with open(log_path,'r') as f:
        ## readlines一次读取整个文件,返回一个列表,供我们便利,文件大小必须小于内存
        for line in f.readlines():

            ## 去掉每行首尾空白
            line = line.strip()

            ## 判断是否为空行,如果为空行,跳过当前空行,继续处理下一行
            if not len(line):
                continue


            ## 获取client ip
            #ip = line.split('の')[2]
            #print ip


            ## 获取client access domain
            try:
                domain = line.split('の')[4]
            except IndexError,e:
                #print "error: domain %s" % e
                continue


            ## 获取client acces url
            #url = line.split('の')[5]
            #print url


            #if ip not in ip_info:
            #    ip_info[ip] = {url:1}
            #else:
            #    if url not in ip_info[ip]:
            #        ip_info[ip][url] = 1
            #    else:
            #        ip_info[ip][url] += 1


            ## 判断域名是否在字典中,如果不在字典中,就把域名作为key,对应的value为1
            ## 如果域名在字典中,就把域名对应的value加1
            if domain not in ip_info:
                ip_info[domain] = 1
            else:
                ip_info[domain] += 1

    ## 删除字典中key值是-的元素
    if '-' in ip_info.keys():
        del ip_info['-']


    ## 把字典转变成可迭代的对象,由元组组成的列表
	## 通过lambda函数进行比较,使用sorted进行排序同时取22行,这样下面再次处理就无需耗费太多资源
    old_result = sorted(ip_info.items(), lambda x, y: cmp(x[1], y[1]), reverse=True)[0:23]


    ## 这里使用了re.match()方法匹配IP和IP:PORT,使用re.search(),re.findall(),re.compile()都可以,具体差别请自行了解
	## 这里的原数据是经过处理的,key是域名或IP或IP:PORT,value是key访问次数,所以re的方法可以使用,用re.search会更好
	## 这里使用了严格匹配方法,即,只匹配IP,只匹配IP:PORT,也可以使用模糊匹配
    ## python中字符串前面加上 r 表示原生字符串,有了原生字符串,再也不用担心是不是漏写了反斜杠,写出来的表达式也更直观
    ## 这里为了简单没有使用异常处理,直接用continue;如果想记录日志,使用异常处理同时记录日志
    ## re.search or re.match,如果加group就会出现None错误


    ## re.search()
    for k,v in old_result:
        if re.search(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', k) != None:
            continue
        elif re.search(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:(\d+)$', k) != None:
            continue

        new_ip_info[k] = v


    ## re.match()
    #for k,v in old_result:
    #    if re.match(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', k) != None:
    #        continue
    #    elif re.match(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:(\d+)$', k) != None:
    #        continue

    #    new_ip_info[k] = v


    ## 模糊匹配,同时匹配IP和IP:PORT
    #for k,v in old_result:
    #    if re.match(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', k) != None:
    #        continue

    #    new_ip_info[k] = v

    new_result = sorted(new_ip_info.items(), lambda x, y: cmp(x[1], y[1]), reverse=True)


    for k,v in new_result:
        # python 2.6.6
        #print CP + ' ' + '{0} {1}'.format(str(v),k)
        #print ("%-5s" % CP) + ("%-10d" % v) + ("%-10s" % k)
        result2 = ("%-5s" % CP) + ',' + ("%-10d" % v) + ',' + ("%-10s" % k) + '\n'
        #result2 = CP + ',' + '{1},{0}'.format(str(v),k) + '\n'

        # python 2.7.11
        #print '{:10s} {:<10s}'.format(str(v),k)
        #result2 = '{:10s} {:<10s}'.format(str(v),k) + '\n'

        with open(result3, 'a+') as f2:
            f2.write(result2)
        f2.close()

    f.close()


## sendmail
def SendMail():
    HOST = "1.1.1.1"
    PORT = "25"
    SUBJECT = u"产品域名统计"
    TO = ["to_mail1","to_mail2"]
    FROM = "from_mail"
    CC = ["cc_mail"]


    tolist = ','.join(TO)
    cclist = ','.join(CC)



    # 创建一个MIMEText对象，HTML元素包括文字与图片<img>
    msgtext2 = MIMEText('排名前20的域名:' + '\n' + open(result3,"rb").read().replace(',',' '))
    msgtext1 = MIMEText("""
        <table width="800" border="0" cellspacing="0" cellpadding="4">
            <tr>
                <td bgcolor="#CECFAD" height="20" style="font-size:14px">排名前20的域名: <a href="www.w66.com">点我点我</a></td>
            </tr>

        </table>""","html","utf-8")


    msg = MIMEMultipart()
    #msg.attach(msgtext1)
    msg.attach(msgtext2)


    # 创建一个MIMEText对象，附加excel表格week_report.xlsx文档
    #print result3
    attach = MIMEText(open(result3,"rb").read(), "base64", "utf-8")
    attach["Content-Type"] = "application/octet-stream"  # 指定文件格式类型
    attach["Content-Disposition"] = "attachment; filename=\"web_domain_count.csv\"".decode("utf-8").encode("utf-8")
    msg.attach(attach)


    msg['Subject'] = SUBJECT
    msg['From'] = FROM
    msg['To'] = tolist
    msg['Cc'] = cclist


    try:
        server = smtplib.SMTP()
        server.connect(HOST, PORT)
        #server.starttls()
        #server.login("test@gmail.com","123456")
        server.sendmail(FROM, TO + CC, msg.as_string())
        server.quit()
        #print "send mail success!"
    except Exception, e:
        print "Error: " + str(e)



if __name__ == "__main__":
    #CPS = ['A01', 'A02', 'A03', 'A04', 'A05', 'A07', 'B01', 'C01', 'C02', 'E02', 'E03', 'E04']
    CPS = ['A01', 'A03', 'A04', 'A05', 'A07', 'B01', 'C02', 'E02', 'E03', 'E04']
    #CPS = ['A03', 'A04', 'A05']
    ROLE = 'web'

    result3 = backupdir + '/' + 'web_domain_count.csv'
    os.system('rm -f ' + result3)

    for CP in CPS:
        #print '-------------%s-----------' % CP
        LOG_DIR = '/data/' + CP + '/' + ROLE + '/access_log'
        if getfile() is 0:
            print
            continue
        treatfile()
        #print

    SendMail()
    time2 = now()
    #print
    #print 'run time is ' + str(time2 - time1) + 's'
